GHOST MEDIA STUDIO WEBSITE
Open index.html in a browser to preview.
Upload the entire folder (or ZIP contents) to a static host such as Cloudflare Pages or Netlify.
Keep the assets folder alongside index.html.
Contact: ghosmediastudios3@gmail.com | (541) 706-0727
Service area: Redmond, Oregon and Central Oregon.
Portfolio captions describe the supplied designs as concepts/promotional work; adjust them if you want to clarify production status or client permissions.
